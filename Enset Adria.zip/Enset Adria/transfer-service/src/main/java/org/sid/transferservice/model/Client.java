package org.sid.transferservice.model;

import lombok.Data;

@Data
public class Client {
    private Long id;
    private String clientName;
    private String clientEmail;
}