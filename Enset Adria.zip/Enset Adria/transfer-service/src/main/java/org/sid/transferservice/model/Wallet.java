package org.sid.transferservice.model;

import jakarta.persistence.ManyToOne;
import lombok.Data;

import java.util.Date;

@Data
public class Wallet {
    private String id;
    private double balance;
    private Date creationDate;
    private String currency;
    private Client client;
}
