package org.sid.transferservice.repositories;

import org.sid.transferservice.entities.Transfer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.data.rest.core.annotation.RestResource;

import java.util.List;
import java.util.Map;

@RepositoryRestResource
public interface TransferRepository extends JpaRepository<Transfer,Long> {

//    @RestResource(path="/byClientId")
//    List<Transfer> findByClientId(@Param("clientId") Long clientId);
//
//    @RestResource(path="/byWalletId")
//    List<Transfer> findByWalletId(@Param("walletId") Long walletId);

}
