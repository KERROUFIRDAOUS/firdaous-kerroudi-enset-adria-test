package org.sid.transferservice.web;

import org.sid.transferservice.entities.Transfer;
import org.sid.transferservice.feign.ClientRestClient;
import org.sid.transferservice.feign.WalletRestClient;
import org.sid.transferservice.model.Wallet;
import org.sid.transferservice.repositories.TransferRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

public class TransferRestController {
    private TransferRepository transferRepository;
    private ClientRestClient clientRestClient;
    private WalletRestClient walletRestClient;

    public TransferRestController(TransferRepository transferRepository, ClientRestClient clientRestClient, WalletRestClient walletRestClient) {
        this.transferRepository = transferRepository;
        this.clientRestClient = clientRestClient;
        this.walletRestClient = walletRestClient;
    }
//    @GetMapping(path = "/transfers/{id}")
//    public Transfer getTransfer(@PathVariable(name = "id") Long id){
//        Transfer transfer = transferRepository.findById(id).get();
//        Wallet wallet = walletRestClient.getWalletById(transfer.getWallet().getId());
//        transfer.setWallet(wallet);
//
//        return bill;
//
//    }
}
