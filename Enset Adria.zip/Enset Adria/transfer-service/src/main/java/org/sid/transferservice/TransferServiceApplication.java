package org.sid.transferservice;

import org.sid.transferservice.entities.Transfer;
import org.sid.transferservice.enums.TransferType;
import org.sid.transferservice.feign.WalletRestClient;
import org.sid.transferservice.model.Wallet;
import org.sid.transferservice.repositories.TransferRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.Date;

@SpringBootApplication
public class TransferServiceApplication {


	public static void main(String[] args) {
		SpringApplication.run(TransferServiceApplication.class, args);
	}

	@Bean
	CommandLineRunner start(TransferRepository transferRepository) {
		return args -> {

			Transfer transfer1 = new Transfer();
			transfer1.setDate(new Date());
			transfer1.setSourceWalletId("source1");
			transfer1.setWalletId("1");
			transfer1.setDestinationWalletId("desitination1");
			transfer1.setAmount(50.00);
			transfer1.setTransferType(TransferType.VALIDATED);

			transferRepository.save(transfer1);

			transferRepository.findAll().forEach(t -> System.out.println(t.toString()));
		};
	}
}
