package org.sid.transferservice.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.sid.transferservice.enums.TransferType;
import org.sid.transferservice.model.Wallet;

import java.util.Date;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Transfer {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Date date;
    private String sourceWalletId;
    private String destinationWalletId;
    private Double amount;
    private TransferType transferType;
//    @Transient
//    private Wallet wallet;
    private String walletId;
}
