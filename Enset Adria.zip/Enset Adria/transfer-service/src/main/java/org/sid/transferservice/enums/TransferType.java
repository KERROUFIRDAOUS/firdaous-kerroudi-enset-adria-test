package org.sid.transferservice.enums;


public enum TransferType {
    PENDIND, VALIDATED, REJECTED
}
