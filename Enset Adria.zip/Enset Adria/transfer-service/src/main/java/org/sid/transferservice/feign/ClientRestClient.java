package org.sid.transferservice.feign;

import org.sid.transferservice.model.Client;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "WALLET-SERVICE")
public interface ClientRestClient {
    @GetMapping(path="/clients/{id}")
    Client getClientById(@PathVariable(name = "id") Long id);
}
