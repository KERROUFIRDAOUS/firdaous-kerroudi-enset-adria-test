package org.sid.walletservice;

import org.sid.walletservice.entities.Client;
import org.sid.walletservice.entities.Wallet;
import org.sid.walletservice.repositories.ClientRepository;
import org.sid.walletservice.repositories.WalletRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.Date;

@SpringBootApplication
public class WalletServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(WalletServiceApplication.class, args);
	}

	@Bean
	CommandLineRunner start(WalletRepository walletRepository, ClientRepository clientRepository) {
		return args -> {

			Client client1 = new Client(null, "Firdaous", "firdaous@example.com");
			Client client2 = new Client(null, "Ayoub", "ayoub@example.com");

			clientRepository.save(client1);
			clientRepository.save(client2);


			Wallet wallet1 = new Wallet();
			wallet1.setId("1");
			wallet1.setBalance(100.00);
			wallet1.setCreationDate(new Date());
			wallet1.setCurrency("USD");
			wallet1.setClient(client1);

			Wallet wallet2 = new Wallet();
			wallet2.setId("2");
			wallet2.setBalance(50.00);
			wallet2.setCreationDate(new Date());
			wallet2.setCurrency("EUR");
			wallet2.setClient(client2);

			walletRepository.save(wallet1);
			walletRepository.save(wallet2);


			walletRepository.findAll().forEach(w -> System.out.println(w.toString()));
			clientRepository.findAll().forEach(c -> System.out.println(c.toString()));
		};
	}
}