package org.sid.gatewaysevice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GatewaySeviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
